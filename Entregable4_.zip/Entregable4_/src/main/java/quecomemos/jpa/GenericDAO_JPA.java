package quecomemos.jpa;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import quecomemos.dao.GenericDAO;
import quecomemos.util.EMF;

public class GenericDAO_JPA<T> implements GenericDAO<T> {
	protected Class<T> clasePersistente;

	public GenericDAO_JPA(Class<T> clase) {
		this.clasePersistente = clase;
	}

	@Override
	public T persistir(T entity) {
		EntityManager em = EMF.getEMF().createEntityManager();
		EntityTransaction tx = null;
		try {
			tx = em.getTransaction();
			tx.begin();
			em.persist(entity);
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
			throw e; // escribir en un log o mostrar un mensaje
		} finally {
			em.close();
		}
		return entity;
	}

	@Override
	public T actualizar(T entity) {
		EntityManager em = EMF.getEMF().createEntityManager();
		EntityTransaction etx = em.getTransaction();
		etx.begin();
		T entityMerged = em.merge(entity);
		etx.commit();
		em.close();
		return entityMerged;
	}

	@Override
	public void borrar(T entity) {
		EntityManager em = EMF.getEMF().createEntityManager();
		EntityTransaction tx = null;
		try {
			tx = em.getTransaction();
			tx.begin();
			em.remove(em.merge(entity));
			tx.commit();
		} catch (RuntimeException e) {
			if (tx != null && tx.isActive()) {
				tx.rollback();
			}
			throw e; // escribir en un log o mostrar un mensaje
		} finally {
			em.close();
		}
	}

	@Override
	public T borrar(Long id) {
	    EntityManager em = EMF.getEMF().createEntityManager();
	    EntityTransaction tx = em.getTransaction(); 

	    T entity = em.find(this.getPersistentClass(), id);
	    if (entity != null) {
	        try {
	            tx.begin(); 
	            em.remove(entity); 
	            tx.commit(); 
	        } catch (Exception e) {
	            if (tx.isActive()) {
	                tx.rollback();
	            }
	            throw e;
	        } finally {
	            em.close(); 
	        }
	    } else {
	        em.close(); 
	    }

	    return entity;
	}

	private Class<T> getPersistentClass() {
		return clasePersistente;
	}

	@Override
	public boolean existe(Long id) {
		EntityManager em = EMF.getEMF().createEntityManager();
		boolean exists = em.find(clasePersistente, id) != null;
		em.close();
		return exists;
	}

	@Override
	public T recuperar(Serializable id) {
		EntityManager em = EMF.getEMF().createEntityManager();
		T entity = em.find(clasePersistente, id);
		em.close();
		return entity;
	}

	@Override
	public List<T> recuperarTodos(String column) {
		EntityManager em = EMF.getEMF().createEntityManager();
		String orderByColumn = (column == null || column.isEmpty()) ? "id" : column;

		List<T> entities = em
				.createQuery("SELECT e FROM " + clasePersistente.getSimpleName() + " e ORDER BY e." + orderByColumn,
						clasePersistente)
				.getResultList();
		em.close();
		return entities;
	}

}